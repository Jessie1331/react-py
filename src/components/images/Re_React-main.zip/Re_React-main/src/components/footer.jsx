import "./footer.css"
function Footer(){
    return(
        <div className="footer">
        <label>Get 30% when you sign up for our weekly E-Catalog </label>
        <button>Sign-up</button>
 </div>
    );
}
export default Footer;