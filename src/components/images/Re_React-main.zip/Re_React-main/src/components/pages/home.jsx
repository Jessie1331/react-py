import "./home.css";

function Home(){


    return(
        <div className="home">
            <h1>Welcome to Diss</h1>
            <h2>We prid ourself on our unique and stylesh designs</h2>
            <img src="/../assets/images/diss.png" alt="diss "/>
            <h3>We are here to help you</h3>
            <p>We started up in 2001 with just a dream and a computer. from there we rose to be what we are today</p>
            <p>we  are based in 26 countrys </p>
            <p>we were voted #1 in inivation</p>
            <p>voted the best in ShoeWear and Design </p>
            <p>You Wont Find Shoes like ours</p>
            <p>lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut</p>
            <div className="flexrow">
                <div>
                  
                </div>

            </div>
        </div>
    );
}
export default Home;