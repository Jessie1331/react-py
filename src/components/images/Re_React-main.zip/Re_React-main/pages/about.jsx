import './about.css';

function About(){



return(
    <div className="about">
        <h2>hi</h2>
    </div>
);
}
export default About;