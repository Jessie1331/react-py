import "./inventory.css";

function Inventory(){

    return(
        <div className="inventory">
            <h2>hi</h2>
        </div>
    );
}
export default Inventory;