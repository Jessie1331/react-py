import "./footer.css"
function Footer(){
    return(
        <div className="footer">
        <label>Get 30% off when you sign up <button className='btn btnsm btn-success'>Sign-up</button></label>
        
 </div>
    );
}
export default Footer;