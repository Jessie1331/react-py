import './about.css';

function About(){



return(
    <div className="about">
      <h1>About Diss</h1>
         
       <div className="parent">
        <h3>Disigner</h3> 
        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nobis sint, quas quaerat mollitia magnam, blanditiis minima reiciendis quisquam vero molestiae rerum! Eum nihil cumque asperiores tenetur iste odit sint sit?</p>
      
        <div className='flex-container'>  
       <div>
        <h3>Our Value</h3>
        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nobis sint, quas quaerat mollitia magnam, blanditiis minima reiciendis quisquam vero molestiae rerum! Eum nihil cumque asperiores tenetur iste odit sint sit?</p>
       </div> 
       <div>
        <h3>Our Mission</h3>
        <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Repellendus hic, iure autem nisi unde nam accusamus, rerum aut ab corporis explicabo debitis, magni quidem minus veniam dolores culpa exercitationem animi.</p>
        </div>
    
      <div>
        <h3>Our Vision</h3>
        <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Repellendus hic, iure autem nisi unde nam accusamus, rerum aut ab corporis explicabo debitis, magni quidem minus veniam dolores culpa exercitationem animi.</p>
      </div>
  </div>
    <div>
        <h3>Secirity/Protection</h3>
        <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Non distinctio hic dolor accusamus fugit fugiat consequuntur voluptate atque laboriosam. Fugiat velit ut suscipit! Id ut, dolores a alias ducimus pariatur.</p>
    </div>
     </div>
    </div>
      
);
}
export default About;